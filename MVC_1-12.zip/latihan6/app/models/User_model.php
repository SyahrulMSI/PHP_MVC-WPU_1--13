<?php 

    class User_model {
        private $nama = 'Mas Syahrul';

        public function getUser()
        {
            return $this->nama;
        }
    }

?>