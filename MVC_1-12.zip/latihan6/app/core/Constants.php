<?php

    define('BASEURL', 'http://localhost/latihan6/public/');

?>