<?php 

    class App {
        public function __construct()
        {
            echo 'Oke';
        }
    }

?>