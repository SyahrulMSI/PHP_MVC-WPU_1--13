<?php

    // Menjalankan Teknik Bootstraping
    require_once '../app/init.php';

    // Menjalankan Class App
    $app = new App;
?>