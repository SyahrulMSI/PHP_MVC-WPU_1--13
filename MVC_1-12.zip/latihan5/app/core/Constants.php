<?php

    define('BASEURL', 'http://localhost/latihan5/public/');

?>