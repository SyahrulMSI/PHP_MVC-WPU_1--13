<?php

    define('BASEURL', 'http://localhost/latihan12/public');

    // Memmbungkus koneksi database
    define('DB_HOST', 'localhost');
    define('DB_USER', 'root');
    define('DB_PASS', '');
    define('DB_NAME', 'phpmvc');
    
?>