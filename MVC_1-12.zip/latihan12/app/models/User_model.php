<?php 

    class User_model {
        private $nama = 'Mas Syahrul MSI';

        public function getUser()
        {
            return $this->nama;
        }
    }

?>