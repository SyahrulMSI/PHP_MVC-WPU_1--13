<?php 

    class User_model {
        private $nama = 'Syahrul MSI';

        public function getUser()
        {
            return $this->nama;
        }
    }

?>