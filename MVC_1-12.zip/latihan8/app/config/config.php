<?php

    define('BASEURL', 'http://localhost/latihan8/public');

    // Memmbungkus koneksi database
    define('DB_HOST', 'localhost');
    define('DB_USER', 'root');
    define('DB_PASS', '');
    define('DB_NAME', 'phpmvc');
    
?>